using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyCompany("AimAssistPlugin")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+a952e78753ac0726c6ac30b9838f741916cfa4de")]
[assembly: AssemblyProduct("AimAssistPlugin")]
[assembly: AssemblyTitle("AimAssistPlugin")]
[assembly: AssemblyVersion("1.0.0.0")]
